# @spresenter/plugin-sdk

Official SDK for building **Spresenter** plugins.

The package version tracks the Spresenter app version (currently `0.2.11`).

## Model

A plugin runs in **two threads**, like Figma:

| Thread | File | Environment | Talks to |
|--------|------|-------------|----------|
| **Logic** | `code.ts` | Isolated process, no DOM | The app, via the global `spresenter` |
| **UI** | `ui/` | Sandboxed `<iframe>` | Only `code.ts`, via `postMessage` |

The UI never talks to the app or the host directly. Every privileged call
originates in the logic thread and is checked against the plugin's declared
`permissions` before reaching the app. Under the hood, each SDK method maps 1:1
to the same core that powers the Spresenter public REST API (`/api/v1`) — no
business logic is reimplemented on the plugin side.

```
UI (iframe) ⇄ postMessage ⇄ code.ts ⇄ host ⇄ app cores (live, assets, media, timer…)
```

## Entry points

```ts
// Logic thread — types only; the runtime is injected by the host.
import '@spresenter/plugin-sdk/code';

spresenter.assets.search('amazing grace', { type: 'music' });
spresenter.live.apply('0', 0, presentation);
spresenter.on('live', ({ output }) => { /* re-fetch */ });
```

```ts
// UI thread — real runtime, bundled into your UI build.
import { postMessage, onMessage } from '@spresenter/plugin-sdk/ui';

postMessage({ type: 'go-live', guid });
const off = onMessage((msg) => { /* messages from code.ts */ });
```

## `spresenter` API (logic thread)

| Namespace | Methods | Scope |
|-----------|---------|-------|
| `outputs` | `list()` | `outputs:read` |
| `layers` | `list()` | `outputs:read` |
| `live` | `read`, `readState`, `apply`, `clear`, `setState`, `setMaster`, `setMusicVerse` | `live:read` / `live:write` |
| `assets` | `get`, `list`, `search`, `getLyrics` | `assets:read` |
| `media` | `getState`, `play`, `pause`, `seek` | `media:read` / `media:write` |
| `timer` | `get`, `set`, `clear` | `timer:read` / `timer:write` |
| `events` | `getActive`, `list` | `events:read` |
| `thumbnails` | `render` | `assets:read` |
| `storage` | `get`, `set`, `delete`, `keys` | — (per-plugin, isolated) |
| `on(event, cb)` | `live` \| `state` \| `media` \| `timer` | scope of the event |
| `ui` | `showPanel`, `showWindow`, `resize`, `close`, `postMessage`, `onmessage` | — |

Events are **notification-only**: the payload carries at most an `output` id;
fetch fresh data with the read methods after receiving one.

## UI kit (shared components)

So every plugin looks like a native part of Spresenter instead of styling its
own widgets, the SDK ships a shared design system that matches the host theme.

```ts
// One stylesheet, two component flavours — pick the one your UI is built with.
import { injectStyles } from '@spresenter/plugin-sdk/ui-kit';

// React plugins:
import { Root, Header, Panel, Field, TextInput, Button, Segmented }
  from '@spresenter/plugin-sdk/ui-kit/react';

// Vanilla (no framework) plugins — same names, DOM-node factories:
import { Root, Header, Field, TextInput, Button } from '@spresenter/plugin-sdk/ui-kit';

injectStyles(); // once at startup (idempotent)
```

Components: `Root`, `Header`, `Panel`, `Row`, `Stack`, `Field`, `TextInput`,
`TextArea`, `Select`, `Checkbox`, `Button` (`primary`/`secondary`/`success`/`danger`/`ghost`),
`Actions`, `Segmented`, `StatusIndicator`, `Alert`, `Footer`, `Hint`. All are
driven by `sp-*` CSS classes and CSS variables you can override.

## Manifest

```json
{
  "id": "com.example.my-plugin",
  "name": "My Plugin",
  "version": "0.2.11",
  "minAppVersion": "0.2.11",
  "sdk": "0.2.11",
  "main": "dist/code.js",
  "ui": "dist/ui/index.html",
  "permissions": ["outputs:read", "assets:read", "live:write"],
  "panels": [{ "id": "main", "title": "My Plugin", "icon": "puzzle" }]
}
```

- `permissions` must be a subset of the scopes above; unknown scopes fail install.
- `panels` declare docked tabs inside the app (rendered without running code).
- `ui` can also be shown as a floating window via `spresenter.ui.showWindow()`.

## Scaffolding

The fastest way to start is **Settings → Plugins → Create plugin…** inside
Spresenter, which generates a ready-to-build project (Vite + Tailwind + this SDK)
from the official template.

## Build

```bash
npm install
npm run build   # emits dist/ (ui.js, ui.cjs, protocol.js, protocol.cjs, d.ts)
```

## License

MIT.
