// @spresenter/plugin-sdk/ui-kit/react — React components for plugin UIs.
//
// Thin wrappers over the shared `sp-*` design-system classes (same stylesheet
// as the vanilla kit — call injectStyles() once at startup). Gives React-based
// plugins ready-made panels/fields/buttons that match the host app theme.
//
//   import { injectStyles } from '@spresenter/plugin-sdk/ui-kit';
//   import { Root, Header, Panel, Field, TextInput, Button, Segmented }
//     from '@spresenter/plugin-sdk/ui-kit/react';
//   injectStyles();

import * as React from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'success' | 'danger' | 'ghost';
export type StatusState = 'idle' | 'ok' | 'warn' | 'connecting' | 'error';

const cx = (...parts: Array<string | false | undefined>) => parts.filter(Boolean).join(' ');

/** Root screen wrapper (dark background, padding, vertical stack). */
export function Root({ className, ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cx('sp-root', className)} {...rest} />;
}

/** Title + optional subtitle header. */
export function Header({ title, subtitle }: { title: React.ReactNode; subtitle?: React.ReactNode }) {
  return (
    <header className="sp-header">
      <h1 className="sp-header__title">{title}</h1>
      {subtitle != null && <p className="sp-header__subtitle">{subtitle}</p>}
    </header>
  );
}

/** Grouped card with an optional uppercase label. */
export function Panel({
  label,
  className,
  children,
  ...rest
}: { label?: React.ReactNode } & React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cx('sp-panel', className)} {...rest}>
      {label != null && <span className="sp-panel__label">{label}</span>}
      {children}
    </div>
  );
}

/** Horizontal flex row. */
export function Row({ className, ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cx('sp-row', className)} {...rest} />;
}

/** Vertical flex stack. */
export function Stack({ className, ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cx('sp-stack', className)} {...rest} />;
}

/** Labeled control wrapper. Children are the control(s). */
export function Field({
  label,
  hint,
  grow,
  className,
  style,
  children,
  ...rest
}: {
  label: React.ReactNode;
  hint?: React.ReactNode;
  grow?: number;
} & React.LabelHTMLAttributes<HTMLLabelElement>) {
  // `grow` controls how the field shares the row's width. The base `.sp-field`
  // class sets `flex: 1` (basis 0%), so passing the shorthand `flex: 0` would
  // ALSO set basis to 0% — which overrides any explicit `width` and collapses
  // the field to near-zero. So: grow 0 → `0 0 auto` (fixed size, honors width);
  // grow > 0 → `${grow} 1 0%` (grows and shares space).
  const flexStyle: React.CSSProperties | undefined =
    grow != null ? { flex: grow === 0 ? '0 0 auto' : `${grow} 1 0%` } : undefined;
  return (
    <label
      className={cx('sp-field', className)}
      style={flexStyle || style ? { ...flexStyle, ...style } : undefined}
      {...rest}
    >
      <span className="sp-field__label">{label}</span>
      {children}
      {hint != null && <span className="sp-field__hint">{hint}</span>}
    </label>
  );
}

/** Text / number / password input. */
export const TextInput = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  function TextInput({ className, ...rest }, ref) {
    return <input ref={ref} className={cx('sp-input', className)} {...rest} />;
  },
);

/** Multi-line text input. */
export const TextArea = React.forwardRef<
  HTMLTextAreaElement,
  React.TextareaHTMLAttributes<HTMLTextAreaElement> & { mono?: boolean }
>(function TextArea({ className, mono, ...rest }, ref) {
  return (
    <textarea
      ref={ref}
      className={cx('sp-textarea', mono && 'sp-textarea--mono', className)}
      {...rest}
    />
  );
});

/** Dropdown select. */
export const Select = React.forwardRef<
  HTMLSelectElement,
  React.SelectHTMLAttributes<HTMLSelectElement>
>(function Select({ className, ...rest }, ref) {
  return <select ref={ref} className={cx('sp-select', className)} {...rest} />;
});

/** Checkbox with an inline label. */
export function Checkbox({
  label,
  className,
  ...rest
}: { label: React.ReactNode } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className={cx('sp-checkbox', className)}>
      <input type="checkbox" className="sp-checkbox__input" {...rest} />
      <span>{label}</span>
    </label>
  );
}

const BTN_VARIANT: Record<ButtonVariant, string> = {
  primary: 'sp-btn--primary',
  secondary: '',
  success: 'sp-btn--success',
  danger: 'sp-btn--danger',
  ghost: 'sp-btn--ghost',
};

/** Action button. Variant defaults to `secondary`. */
export function Button({
  variant = 'secondary',
  size,
  block,
  className,
  type,
  ...rest
}: {
  variant?: ButtonVariant;
  size?: 'sm' | 'md';
  block?: boolean;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type={type ?? 'button'}
      className={cx('sp-btn', BTN_VARIANT[variant], size === 'sm' && 'sp-btn--sm', block && 'sp-btn--block', className)}
      {...rest}
    />
  );
}

/** Button row. Use <Actions.Spacer/> to push following buttons right. */
export function Actions({ className, ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cx('sp-actions', className)} {...rest} />;
}
Actions.Spacer = function Spacer() {
  return <span className="sp-actions__spacer" />;
};

/** Segmented control (mutually exclusive toggle buttons). */
export function Segmented<T extends string>({
  value,
  options,
  onChange,
  className,
}: {
  value: T;
  options: Array<{ value: T; label: React.ReactNode }>;
  onChange: (value: T) => void;
  className?: string;
}) {
  return (
    <div className={cx('sp-segmented', className)}>
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          className={cx('sp-segmented__option', o.value === value && 'sp-segmented__option--active')}
          onClick={() => onChange(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

/** Status indicator (colored dot + label + detail). */
export function StatusIndicator({
  state = 'idle',
  label,
  detail,
}: {
  state?: StatusState;
  label?: React.ReactNode;
  detail?: React.ReactNode;
}) {
  return (
    <div className={cx('sp-status', state !== 'idle' && `sp-status--${state}`)}>
      <span className="sp-status__dot" />
      {label != null && <span className="sp-status__label">{label}</span>}
      {detail != null && <span className="sp-status__detail">{detail}</span>}
    </div>
  );
}

/** Inline colored message box. */
export function Alert({
  variant = 'info',
  detail,
  children,
}: {
  variant?: 'success' | 'error' | 'warning' | 'info';
  detail?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className={cx('sp-alert', `sp-alert--${variant}`)}>
      <div>{children}</div>
      {detail != null && <div className="sp-alert__detail">{detail}</div>}
    </div>
  );
}

/** Muted footer text. */
export function Footer({ className, ...rest }: React.HTMLAttributes<HTMLElement>) {
  return <footer className={cx('sp-footer', className)} {...rest} />;
}

/** Small muted hint text. */
export function Hint({ className, ...rest }: React.HTMLAttributes<HTMLSpanElement>) {
  return <span className={cx('sp-hint', className)} {...rest} />;
}

export { injectStyles, uiKitCss } from './styles';
