// UI-thread runtime. Bundled into the plugin's UI build. Bridges the plugin UI
// (iframe) to its logic thread (code.ts) via window.postMessage — the UI never
// talks to the host or the app directly.
//
//   import { postMessage, onMessage } from '@spresenter/plugin-sdk/ui';
//   postMessage({ type: 'go-live', guid });      // -> spresenter.ui.onmessage
//   const off = onMessage((msg) => { ... });      // <- spresenter.ui.postMessage

import { SPRESENTER_MARKER, isUiEnvelope } from '../protocol';

/** Send a message from the UI to the plugin logic thread (code.ts). */
export function postMessage(data: unknown): void {
  // The host page is the trusted parent; content is opaque, so '*' is fine.
  window.parent.postMessage({ [SPRESENTER_MARKER]: true, data }, '*');
}

/** Register a handler for messages from the logic thread. Returns unsubscribe. */
export function onMessage(handler: (data: unknown) => void): () => void {
  const listener = (ev: MessageEvent) => {
    if (!isUiEnvelope(ev.data)) return;
    handler(ev.data.data);
  };
  window.addEventListener('message', listener);
  return () => window.removeEventListener('message', listener);
}

export { isUiEnvelope, SPRESENTER_MARKER } from '../protocol';
