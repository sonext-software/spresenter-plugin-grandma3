// Type declarations for the global `spresenter` available inside a plugin's
// logic thread (code.ts). This entrypoint ships TYPES ONLY — the runtime is
// injected by the host, mirroring @figma/plugin-typings. Import it for its
// side-effect of declaring the global:
//
//   import '@spresenter/plugin-sdk/code';
//
// Every method maps 1:1 to a host core that the /api/v1 REST API also uses;
// no business logic is reimplemented plugin-side.

import type {
  OutputSummary,
  LayerSummary,
  LayerState,
  Asset,
  AssetFilters,
  Lyrics,
  Presentation,
  MediaState,
  TimerState,
  EventSummary,
  ActiveEvent,
  PluginManifest,
  AutomationNodeDef,
  AutomationCategoryDef,
  AutomationTriggerDef,
  ElementPatch,
  ElementHandle,
} from '../src/types/domain';

export type PluginEventName = 'live' | 'state' | 'media' | 'timer';

/** One typed OSC argument: string, float or int (`net.oscSend`). */
export interface OscArg {
  type: 's' | 'f' | 'i';
  value: string | number;
}

export interface SpresenterApi {
  /** The parsed manifest.json of this plugin. */
  readonly manifest: PluginManifest;

  outputs: {
    list(): Promise<OutputSummary[]>;
  };
  layers: {
    list(): Promise<LayerSummary[]>;
  };
  live: {
    read(output: string): Promise<(Presentation | null)[]>;
    readState(output: string): Promise<LayerState[]>;
    apply(output: string, layer: number, presentation: Presentation): Promise<void>;
    clear(output: string, layer: number): Promise<void>;
    setState(output: string, layer: number, patch: Partial<LayerState>): Promise<LayerState>;
    setMaster(output: string, opacity: number): Promise<{ opacity: number }>;
    setMusicVerse(output: string, layer: number, assetGuid: string, index: number): Promise<void>;
    /** Control a live theme element by id in real time (no theme reload). */
    setElement(output: string, layer: number, elementId: string, patch: ElementPatch): Promise<void>;
    /** Current element overrides of an output: `{ [layer]: { [elementId]: patch } }`. */
    readElements(output: string): Promise<Record<string, Record<string, ElementPatch>>>;
    /** Grab a live element and modify it freely (chainable): `element(...).setText(...).setStyle(...)`. */
    element(output: string, layer: number, elementId: string): ElementHandle;
  };
  assets: {
    get(guid: string): Promise<Asset | null>;
    list(filters?: AssetFilters): Promise<Asset[]>;
    search(q: string, filters?: AssetFilters): Promise<Asset[]>;
    getLyrics(guid: string): Promise<Lyrics | null>;
  };
  media: {
    getState(): Promise<MediaState>;
    play(): Promise<void>;
    pause(): Promise<void>;
    seek(time: number): Promise<void>;
  };
  timer: {
    get(): Promise<TimerState>;
    set(patch: Partial<TimerState>): Promise<TimerState>;
    clear(): Promise<TimerState>;
  };
  events: {
    getActive(): Promise<ActiveEvent | null>;
    list(): Promise<EventSummary[]>;
  };
  thumbnails: {
    render(presentation: Presentation, width: number, height: number): Promise<string | null>;
  };
  /** Register custom nodes in the automation editor. Requires `background: true`
   *  in the manifest so the node is available even without any UI open. */
  automation: {
    registerNode(def: AutomationNodeDef): void;
    /** Declare a custom category (label + icon) for the "add node" menu, so
     *  this plugin's nodes group under their own section instead of "plugins". */
    registerCategory(def: AutomationCategoryDef): void;
    /** Declare a trigger that this plugin fires. It shows up in the trigger
     *  list; fire it at runtime with emitTrigger(). */
    registerTrigger(def: AutomationTriggerDef): void;
    /** Fire a previously-registered trigger, running matching automations with
     *  this payload (trigger nodes can filter on the payload's fields). */
    emitTrigger(triggerId: string, payload?: Record<string, unknown>): void;
  };
  /** Generic outbound network (requires the `net:connect` permission). Sockets
   *  live in the host. WebSocket events arrive via `net.on(connId, type, cb)`;
   *  `httpRequest` is one-shot request/response. Lets a plugin speak protocols
   *  like obs-websocket or HTTP WebServices/REST entirely on its own. */
  net: {
    /** Open a WebSocket (ws:// or wss://). Resolves with a connection id. */
    wsOpen(url: string): Promise<string>;
    /** Send a text frame on an open connection. */
    wsSend(connId: string, data: string): Promise<boolean>;
    /** Close a connection. */
    wsClose(connId: string): Promise<boolean>;
    /** Listen to a connection's lifecycle. For `type:'message'`, the event's
     *  `data` holds the frame text. Register right after `wsOpen` resolves. */
    on(
      connId: string,
      type: 'open' | 'message' | 'close' | 'error',
      cb: (e: { connId: string; type: string; data?: string; code?: number; message?: string }) => void,
    ): void;
    /** One-shot HTTP request (any method). Never throws on 4xx/5xx — the status
     *  is returned so the plugin can react. Ideal for HTTP WebServices/REST APIs. */
    httpRequest(opts: {
      method?: string;
      url: string;
      headers?: Record<string, string>;
      body?: string;
      timeoutMs?: number;
    }): Promise<{ ok: boolean; status: number; statusText: string; body: string; error?: string }>;
    /** Send one OSC message over UDP (fire-and-forget: there is no reply and no
     *  return path — the host just writes the datagram). Rejects only when the
     *  local send fails (bad address/host/port, socket unavailable); delivery to
     *  the target is never confirmed. Typical use: lighting consoles, e.g.
     *  `oscSend('192.168.0.10', 8000, '/cmd', [{ type: 's', value: 'Go+ Executor 1.201' }])`. */
    oscSend(host: string, port: number, address: string, args?: OscArg[]): Promise<boolean>;
  };
  /** Small crypto helpers (e.g. for auth handshakes). */
  crypto: {
    /** SHA-256 of a UTF-8 string, base64-encoded. */
    sha256Base64(input: string): Promise<string>;
  };
  /** Per-plugin persistent key/value storage (isolated per plugin). */
  storage: {
    get<T = unknown>(key: string): Promise<T | undefined>;
    set(key: string, value: unknown): Promise<void>;
    delete(key: string): Promise<void>;
    keys(): Promise<string[]>;
  };
  /** Subscribe to live/state/media/timer notifications. Returns an unsubscribe fn.
   *  Events are notification-only; fetch fresh data via the methods above. */
  on(event: PluginEventName, cb: (payload: { output?: string }) => void): () => void;
  ui: {
    /** Focus/open this plugin's docked panel tab. */
    showPanel(panelId?: string): Promise<void>;
    /** Open this plugin's UI in a floating native window. */
    showWindow(opts?: { width?: number; height?: number; title?: string }): Promise<void>;
    /** Resize the floating window (if open). */
    resize(width: number, height: number): Promise<void>;
    /** Close the plugin's floating window / UI surface. */
    close(): Promise<void>;
    /** Send a message to the plugin UI (iframe). */
    postMessage(msg: unknown): void;
    /** Assign a handler for messages coming from the plugin UI. */
    onmessage: ((msg: unknown) => void) | undefined;
  };
  /** Terminate the plugin's logic process. */
  closePlugin(): void;
}

declare global {
  const spresenter: SpresenterApi;
}

export {};
